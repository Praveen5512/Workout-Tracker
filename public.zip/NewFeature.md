# Flows Screen --- Feature Specification

## 1. Purpose

Add a new **Flows** screen to the existing ApexTrack Workout Tracker
PWA. The application already has three screens:

1.  Home
2.  Analytics
3.  Workouts

The new Flows screen is an additional screen. Existing screens and their
current behavior must remain intact.

The Flows screen allows users to create their own workout flows, save
them, and play them as guided workout sessions. During playback, the
application focuses on the current workout, shows the next workout, and
tracks the total session time.

This feature has no backend. Flow definitions and session history should
be stored locally in the browser.

## 2. Instructions to the AI Coding Agent

Before implementing this feature:

1.  Inspect the existing repository, framework, routing, navigation,
    styling system, and persistence patterns.
2.  Identify how the current Home, Analytics, and Workouts screens are
    implemented.
3.  Add Flows as a fourth screen using the project's existing
    conventions.
4.  Reuse existing workout-related components or data structures where
    appropriate.
5.  Do not rewrite or unnecessarily refactor the existing screens.
6.  Do not introduce a backend or make API calls for flow definitions or
    session history.
7.  If an implementation detail is not specified in this document,
    inspect the current codebase first. Do not silently assume a product
    behavior that could change the user's intended workflow.

## 3. Flows Screen and Flow Management

The Flows screen must allow users to create and play their own flows.

Users must be able to create a flow containing an ordered sequence of
workouts. A flow's workout sequence determines the order in which the
workouts are presented during playback.

Each workout entry in a flow must contain:

-   Workout/exercise name.
-   Sets.
-   Reps.
-   Workout time: how much time it takes to complete that individual
    workout.

Users must be able to save a created flow and play it later.

The flow-management interface must make it clear which flows the user
has created and allow the user to select a flow to play.

The requirements do not prescribe a particular visual layout or
additional flow-management actions. Follow the existing application's
design conventions and avoid adding unrelated features.

## 4. Workout Time and Session Time

These are two different concepts and must not be treated as
interchangeable.

### 4.1 Workout Time

Workout Time represents how much time it takes to complete an individual
workout in the flow.

It belongs to the individual workout entry and should be shown with that
workout during playback.

### 4.2 Session Time

Session Time represents the total time for the complete flow session,
including:

-   Time spent performing all workouts.
-   Time spent resting during the session.

Session Time is an overall session timer, not the time value of the
current workout.

The timer must accumulate active session time. Time spent while the
session is paused must not be counted.

The requirements do not define a separate rest-duration field or a
specific rest-timer interaction. Inspect the existing application for an
established rest-period behavior, if any. Do not invent a separate rest
workflow without a requirement or existing project convention.
Regardless of how rest periods are represented, time spent resting
during an active session belongs in Session Time.

## 5. Playing a Flow

When a user chooses to play a saved flow, open a session-playback
interface.

### 5.1 Current Workout

-   The current workout must be the main focus of the playback screen.
-   Display the current workout's relevant details, including its name,
    sets, reps, and Workout Time.
-   The current workout is determined by the flow's saved order.

### 5.2 Next Workout

-   Display the next workout in the bottom-right corner of the playback
    interface.
-   The next-workout preview must identify the upcoming workout clearly.
-   When the current workout is marked completed, advance to the next
    workout in the sequence.
-   Update both the main current-workout display and the next-workout
    preview after advancing.
-   For the final workout, there is no next workout; handle this state
    clearly.

### 5.3 Completing a Workout

-   Provide a **Completed** action for the current workout.
-   Selecting Completed marks the current workout as completed for this
    session and advances playback to the next workout.
-   Completing one workout must not restart the Session Time timer.
-   When the final workout is completed, finish the flow session and
    stop the Session Time timer.
-   Save the completed session's time record locally.

### 5.4 Pause and Resume

Users must be able to pause and resume the session timer.

-   Pausing stops Session Time from accumulating.
-   Resuming continues the same session rather than starting a new
    session.
-   Time spent paused must be excluded from the final Session Time.
-   Pausing and resuming must not reset the current workout or lose
    progress through the flow.
-   Completing the final workout stops the timer.
-   Ensure timer calculations remain accurate if the app re-renders or
    the browser tab is temporarily inactive. Do not rely solely on
    incrementing a counter once per UI interval tick if that could cause
    timing drift.

The requirements do not specify whether a user can abandon or restart an
in-progress session. Do not add destructive session controls without
checking existing application conventions or clarifying the behavior.

## 6. Session History and Local Storage

Flow definitions and session-time history must be stored in browser
local storage. There is no backend for this feature.

### 6.1 Data stored locally

Persist the information required to:

-   Reopen saved flow definitions.
-   Display session-time history.
-   Draw the session-time progress graph.
-   Retain session records across page reloads.

Each completed session record must contain, at minimum, enough
information to identify the flow and its completion time and total
Session Time. Use a consistent, documented local data structure that
fits the existing project conventions.

Do not send flow definitions or session history to the existing Google
Apps Script backend.

### 6.2 Thirty-day retention

Session-time history is retained for 30 days only.

-   Automatically delete session-history records older than 30 days.
-   Run the cleanup automatically when the Flows feature loads and
    before history is displayed or used to build the graph.
-   Do not require the user to delete expired records manually.
-   Ensure records within the 30-day retention window remain available
    after page reloads.
-   Use the session completion timestamp to determine a record's age.
-   Apply the same retention rule to all session-history views and
    calculations.

The retention rule applies to **session history**. It must not
automatically delete saved flow definitions.

## 7. Session-Time Progress Graph

The Flows feature must provide a graph showing how the user's Session
Time changes over time.

The graph must:

-   Use completed session records stored locally.
-   Display session time over time in chronological order.
-   Reflect the 30-day history retention policy; records older than 30
    days must not be included.
-   Make it possible to see whether session times are improving,
    worsening, or staying relatively consistent.
-   Update when a new session is completed and saved.
-   Handle an empty history without crashing or showing fabricated
    values.
-   Handle a small number of sessions without implying a trend that the
    data cannot support.

Use a consistent time unit and readable date labels. Do not create
sample or fabricated workout history in the user's actual data.

A lower Session Time may indicate faster completion, but session
duration alone does not prove overall workout improvement. Present the
graph as a trend in session duration and avoid claiming improvement
beyond what the data supports.

## 8. Persistence and Reliability

-   Saved flow definitions must survive page reloads.
-   Completed session records must survive page reloads until they
    expire under the 30-day retention rule.
-   Do not rely on in-memory component state as the only storage for
    flows or session history.
-   Handle missing, malformed, or outdated local data safely so the
    Flows screen does not become unusable.
-   Do not erase saved flow definitions as part of session-history
    cleanup.
-   Do not store a completed session more than once because of repeated
    renders or repeated completion handling.
-   Ensure a session is recorded only when the final workout has been
    completed, in accordance with the defined completion behavior.
-   Keep flow data and session history local to the browser; no backend
    synchronization is required for this feature.

## 9. Navigation and Existing Application Compatibility

-   Add Flows as a fourth screen alongside Home, Analytics, and
    Workouts.
-   Use the existing navigation approach and visual design system.
-   Keep the application responsive, especially on mobile.
-   Do not break existing routes, screens, workout logging, analytics,
    or PWA behavior.
-   Keep the current workout visually prominent during playback.
-   Keep the next-workout preview positioned in the bottom-right corner
    as required.

## 10. Acceptance Criteria

### Flow creation and storage

-   [ ] A fourth screen named Flows is available in the existing
    application.
-   [ ] A user can create a flow containing an ordered list of workouts.
-   [ ] Each workout entry supports a name, sets, reps, and Workout
    Time.
-   [ ] A created flow can be saved.
-   [ ] A saved flow remains available after reloading the application.
-   [ ] Flow definitions are stored locally and are not sent to the
    backend.

### Playback

-   [ ] A user can start a saved flow.
-   [ ] The current workout is the main focus of the playback screen.
-   [ ] The current workout displays its name, sets, reps, and Workout
    Time.
-   [ ] The next workout appears in the bottom-right corner.
-   [ ] Selecting Completed advances to the next workout.
-   [ ] The next-workout preview updates after advancing.
-   [ ] Completing the final workout ends the session and stops Session
    Time.
-   [ ] Advancing between workouts does not reset Session Time.

### Session timer

-   [ ] Session Time includes time spent performing workouts and resting
    during an active session.
-   [ ] The timer can be paused.
-   [ ] The timer can be resumed.
-   [ ] Paused time is excluded from Session Time.
-   [ ] Pause/resume preserves the current workout and flow progress.
-   [ ] Timer calculations remain accurate despite UI re-renders or
    temporary tab inactivity.

### History and retention

-   [ ] A completed session's Session Time is saved locally.
-   [ ] Session history persists across page reloads.
-   [ ] Records older than 30 days are automatically deleted.
-   [ ] Expired records are removed before the graph is built.
-   [ ] History cleanup does not delete saved flow definitions.
-   [ ] A completed session is not recorded multiple times due to
    duplicate event handling.

### Progress graph

-   [ ] The graph uses locally stored completed session records.
-   [ ] Session times are shown in chronological order.
-   [ ] The graph reflects the 30-day retention window.
-   [ ] New completed sessions appear in the graph.
-   [ ] Empty and limited history states are handled without fabricated
    data.
-   [ ] Labels and units make session duration understandable.

### Regression and quality

-   [ ] Existing Home, Analytics, and Workouts screens continue to work.
-   [ ] Existing navigation and PWA behavior remain intact.
-   [ ] The layout is usable on mobile and desktop.
-   [ ] Relevant tests are added or updated.
-   [ ] Build, lint, and tests are run when available; results are
    reported accurately.

## 11. Testing Expectations

Use the repository's existing testing framework. Test at least:

-   Creating and saving a flow with multiple workout entries.
-   Reloading and recovering saved flows.
-   Starting a flow and displaying the first current and next workouts.
-   Advancing through workouts in the saved order.
-   Completing the final workout and stopping the session.
-   Pausing and resuming without counting paused time.
-   Session-time calculation across multiple workouts and rest periods.
-   Saving one session-history record on completion.
-   Retaining records within 30 days and deleting records older than 30
    days.
-   Building graph data in chronological order.
-   Empty history and insufficient-data graph states.
-   Ensuring history cleanup does not delete flow definitions.
-   Ensuring existing application screens and navigation continue to
    work.

Do not claim tests pass unless they have actually been run.

## 12. Completion Report from the AI Coding Agent

After implementation, report:

1.  The files created or modified.
2.  How Flows was integrated with existing navigation.
3.  How flow definitions and session history are stored locally.
4.  How the session timer handles pause/resume and completion.
5.  How the 30-day cleanup is performed.
6.  How the progress graph is calculated.
7.  Which build, lint, and test commands were run and their actual
    results.
8.  Any unresolved limitations or requirements that could not be
    completed.
